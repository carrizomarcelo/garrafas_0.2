---
name: Question
about: Ask a question
labels:

---

Please post your question to StackOverflow: https://stackoverflow.com/questions/ask
Make sure to add the `sweetalert2` tag to the question.

Thank you.

---

Has SweetAlert2 helped you create an amazing application? You can show your support via GitHub Sponsors: https://github.com/sponsors/limonte

Alternative ways for donations (PayPal, cryptocurrencies, etc.) are listed here: https://sweetalert2.github.io/#donations
