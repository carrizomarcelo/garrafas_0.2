---
name: Feature request
about: Wouldn’t it be nice if SweetAlert2 could ...
labels:

---

## New feature motivation

<!-- Describe the context, the use-case and the advantages of the feature request. -->

## New feature description

<!-- Optionally describe the functional changes that would have to be made in SweetAlert2. -->

## New feature implementation

<!-- Optionally describe the technical changes to be made in SweetAlert2. -->


---

Has SweetAlert2 helped you create an amazing application? You can show your support via GitHub Sponsors: https://github.com/sponsors/limonte

Alternative ways for donations (PayPal, cryptocurrencies, etc.) are listed here: https://sweetalert2.github.io/#donations
